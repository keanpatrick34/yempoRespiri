﻿// See https://aka.ms/new-console-template for more information

using System;
using System.Collections.Generic;

namespace yempoRespiriConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            string? idPerson;
            Console.Write("Please enter person id: ");
            idPerson = Console.ReadLine();
            int id = Convert.ToInt32(idPerson);

            HttpClient clientHelloWorldTask = new HttpClient();
            var helloWorldTask = clientHelloWorldTask.GetAsync("https://localhost:7127/api/HelloWorld/" + id);
            helloWorldTask.Wait();
            if (helloWorldTask.IsCompleted) { 
                var result = helloWorldTask.Result;
                if (result.IsSuccessStatusCode) {
                    var message = result.Content.ReadAsStringAsync();
                    message.Wait();
                    Console.WriteLine(message.Result);
                    Console.ReadLine();
                }
            }

            //getAllperson
            Console.WriteLine("getAllperson");
            HttpClient clientGetAllperson = new HttpClient();
            var getAllpersonTask = clientGetAllperson.GetAsync("https://localhost:7127/api/Person/All");
            getAllpersonTask.Wait();
            if (getAllpersonTask.IsCompleted)
            {
                var result = getAllpersonTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var message = result.Content.ReadAsStringAsync();
                    message.Wait();
                    Console.WriteLine(message.Result);
                    Console.ReadLine();
                }
            }


            //get person by id
            Console.WriteLine("PersonById");
            HttpClient clientPersonById = new HttpClient();
            var personByIdTask = clientPersonById.GetAsync("https://localhost:7127/api/Person/" + id);
            personByIdTask.Wait();
            if (personByIdTask.IsCompleted)
            {
                var result = personByIdTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var message = result.Content.ReadAsStringAsync();
                    message.Wait();
                    Console.WriteLine(message.Result);
                    Console.ReadLine();
                }
            }
        }
    }
}
