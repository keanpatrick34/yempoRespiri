﻿using Microsoft.AspNetCore.Mvc;

namespace yempoRespiri.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HelloWorld : Controller
    {
        [HttpGet("{versionNumber}")]
        public string Index(int versionNumber)
        {
            return "Hello World and this is your version Number " + versionNumber;
        }
    }
}
