﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Text.Json;
using yempoRespiri.Models;


namespace yempoRespiri.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : Controller
    {
        [HttpGet("{Id}")]
        public ActionResult<Person> GetPersonDetails(int Id)
        {
            PersonRepository personRepository = new PersonRepository();
            Person person =  personRepository.GetPersonById(Id);
            if (person == null)
            {
                return NotFound();
            }
            return person;
        }

        [HttpGet("All")]
        public JsonResult GetPersonAllDetails()
        {
            PersonRepository personRepository = new PersonRepository();
            var jsonResult = JsonSerializer.Serialize(personRepository.GetPersonAll());
            if (jsonResult == null)
            {
                return Json("error");
            }
            return Json(jsonResult);
        }
    }
}
