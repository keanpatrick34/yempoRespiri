﻿using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace yempoRespiri.Models
{
    public class PersonRepository : IPerson
    {
        public List<Person> DataSource() {
            return new List<Person>()
            {
                new Person() {
                    Id = 101,
                    Name = "John Doe",
                    Title = "Mr",
                    age = 30
                },
                 new Person() {
                    Id = 102,
                    Name = "Jobe Doe",
                    Title = "Mrs",
                    age = 31
                },
                  new Person() {
                    Id = 103,
                    Name = "Johnny Doe",
                    Title = "Mr",
                    age = 32
                },
                   new Person() {
                    Id = 101,
                    Name = "Jelly Doe",
                    Title = "Ms",
                    age = 25
                }
            };
        }

        public Person GetPersonById(int id)
        {
            return DataSource().FirstOrDefault(e => e.Id == id) ?? new Person();
        }

        public List<Person> GetPersonAll()
        {
            List<Person> personList = new List<Person>();
            foreach (Person person in DataSource())
            {
                personList.Add(person);
            }
            return personList;
        }
    }
}
