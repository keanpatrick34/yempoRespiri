﻿namespace yempoRespiri.Models
{
    public interface IPerson
    {
        Person GetPersonById(int Id);

        List<Person> GetPersonAll(); 
    }
}
